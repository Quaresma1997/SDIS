package message;

public class MessageBody {

    private byte[] data;

    public MessageBody(byte[] data) {
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}